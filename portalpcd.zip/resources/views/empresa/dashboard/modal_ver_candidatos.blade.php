<div class="modal-new modal-ver-candidato " style="display:none;">
    <div class="close close-modal-ver-candidatos">
        <span></span>
        <span></span>
    </div>
    
    <div style=" width:960px !important; background:#FFF;"> 
        <div class="dados boxCandVaga"></div>
    </div>
</div>