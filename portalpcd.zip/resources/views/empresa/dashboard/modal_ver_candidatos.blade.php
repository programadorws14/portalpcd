<div class="modal-new modal-ver-candidato " style="display:none;">
    <div class="close close-modal-ver-candidatos">
        <span></span>
        <span></span>
    </div>
    <div style=" width:960px !important; background:#FFF;"> 
        <div class="dados boxCandVaga"></div>
        
        <div class="dados" style="padding-bottom:40px;">
            <a href="#" id="candidatos_excel_vaga" style="padding:20px; margin:10px; background:#333; color:#FFF; text-decoration:none; font-weight:bold; border-radius?10px;">Download Excel</a>
        </div>
    </div>
</div>