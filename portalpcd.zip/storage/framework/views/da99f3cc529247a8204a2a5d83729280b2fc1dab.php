<div class="modal fade" id="verCandidatos<?php echo e($vaga->id); ?>" tabindex="-1" role="dialog" aria-labelledby="verCandidatos<?php echo e($vaga->id); ?>Label" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
      <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="verCandidatos<?php echo e($vaga->id); ?>Label">Candidatos a vaga: <b><?php echo e($vaga->titulo ?? 'N/I'); ?></b></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <b>Candidatos a vaga:</b><br /><br />
            <hr/>
            <br />
            
            <?php if(count($vaga->candidaturas) >= 1): ?>
                <?php $__currentLoopData = $vaga->candidaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="text-left col-md-8">
                        <b> #ID: </b>  <?php echo e($candidato->candidato_vaga->id); ?><br />
                        <b> Nome: </b>  <?php echo e($candidato->candidato_vaga->nome); ?><br />
                        <b> E-mail: </b> <?php echo e($candidato->candidato_vaga->email); ?><br />
                        <b> Telefone: </b>  <?php echo e($candidato->candidato_vaga->telefone_celular ?? 'N/I'); ?> / <?php echo e($candidato->candidato_vaga->telefone_comercial ?? 'N/I'); ?> / <?php echo e($candidato->candidato_vaga->telefone_residencial ?? 'N/I'); ?> 
                    </div>
                    <div class="col-md-2">
                        <a href="#" class="btn btn-sm btn-warning"><b>BAIXAR CV</b></a>
                    </div>
                </div>
                <hr />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal"><b>FECHAR</b></button>
          <button class="btn btn-sm btn-success" ><b>BAIXAR EXCEL</b></button>
        </div>
      </div>
    </div>
  </div><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views/admin/gerenciar_vaga/_modal_candidatos.blade.php ENDPATH**/ ?>