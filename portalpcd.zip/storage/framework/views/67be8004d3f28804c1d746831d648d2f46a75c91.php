<div class="table-responsive">
    <table class="tabelaDinamica table table-striped table-bordered table-hover table-sm">
        <thead class="thead-light">
            <tr>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Empresa</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Titulo</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Salario</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Status</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Tipo Vaga</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Numero Vaga(s)</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">CEP</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Rua</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Número</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Complemento</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Bairro</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Cidade</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Estado</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Candidatos</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Ação</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php if(count($vagas) > 0): ?>
            <?php $__currentLoopData = $vagas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="align-middle p-2"><?php echo e($vaga->empresa->nome ?? 'N/I'); ?></td>
                <td class="align-middle p-2"><?php echo e($vaga->titulo ?? 'N/I'); ?></td>
                <td class="align-middle p-2">
                    <?php if($vaga->salario_acombinar != ''): ?>
                    Salario A Combinar
                    <?php else: ?>
                    Salário de: <?php echo e($vaga->salario_de ?? 'N/I'); ?> <br />
                    Salário ate: <?php echo e($vaga->salario_ate ?? 'N/I'); ?> <br />
                    <?php endif; ?>
                </td>
                <td class="align-middle p-2">
                    <?php if($vaga->pausar_vaga == ''): ?>
                    <span class="badge badge-success">Ativa</span>
                    <?php else: ?>
                    <span class="badge badge-secondary">Pausada</span>
                    <?php endif; ?>
                </td>
                <td class="align-middle p-2"><?php echo e($vaga->tipo_emprego ?? 'N/I'); ?></td>
                <td class="align-middle p-2"><?php echo e($vaga->numero_vagas ?? 'N/I'); ?></td>
                <td class="align-middle p-2"><?php echo e($vaga->cep ?? 'N/I'); ?></td>
                <td class="align-middle p-2"><?php echo e($vaga->rua ?? 'N/I'); ?></td>
                <td class="align-middle p-2"><?php echo e($vaga->numero ?? 'N/I'); ?></td>
                <td class="align-middle p-2"><?php echo e($vaga->complemento ?? 'N/I'); ?></td>
                <td class="align-middle p-2"><?php echo e($vaga->bairro ?? 'N/I'); ?></td>
                <td class="align-middle p-2"><?php echo e($vaga->cidade ?? 'N/I'); ?></td>
                <td class="align-middle p-2"><?php echo e($vaga->estado ?? 'N/I'); ?></td>
                <td class="align-middle p-2">
                <?php if(count($vaga->candidaturas) > 0): ?>
                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#verCandidatos<?php echo e($vaga->id); ?>"> <i class="fas fa-users"></i> Candidatos</button>
                    <?php echo $__env->make('admin.gerenciar_vaga._modal_candidatos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php else: ?> 
                    <span class="badge badge-info">Não há candidatos</span>
                <?php endif; ?>
                </td>
                <td class="align-middle p-2">
                    <a href="<?php echo e(route('admin.gerenciar.vaga.edit', $vaga->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a>
                    <a href="#" onClick="return confirm('Deseja mesmo deletar ?')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
</div><?php /**PATH C:\wamp64\www\jobs\portalpcd\resources\views/admin/gerenciar_vaga/_list.blade.php ENDPATH**/ ?>