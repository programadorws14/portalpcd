<div class="modal-new modal-ver-candidato " style="display:none;">
    <div class="close close-modal-ver-candidatos">
        <span></span>
        <span></span>
    </div>
    
    <div style=" width:960px !important; background:#FFF;"> 
        <div class="dados boxCandVaga"></div>
    </div>
</div><?php /**PATH C:\wamp64\www\jobs\portalpcd\resources\views/empresa/dashboard/modal_ver_candidatos.blade.php ENDPATH**/ ?>