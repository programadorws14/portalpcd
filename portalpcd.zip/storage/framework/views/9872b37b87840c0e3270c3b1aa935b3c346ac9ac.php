<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php if(Session('success')): ?>
            <div class="alert alert-success">
                <b><i class="fas fa-check"></i> <?php echo e(Session('success')); ?></b>
            </div>
            <?php elseif(Session('error')): ?>
            <div class="alert alert-danger">
                <b><i class="fas fa-minus"></i> <?php echo e(Session('error')); ?></b>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('admin.empresa.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-header">Nova Empresa</div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Logotipo</div>
                                    </div>
                                    <input type="file" class="form-control" value="" accept="image/*" name="logo">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Nome</div>
                                    </div>
                                    <input type="text" class="form-control" value="" name="nome">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">E-mail</div>
                                    </div>
                                    <input type="email" class="form-control" value="" name="email">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Senha</div>
                                    </div>
                                    <input type="password" class="form-control" value="" name="password">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Descrição</div>
                                    </div>
                                    <input type="text" class="form-control" value="" name="descricao">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Ramo</div>
                                    </div>
                                    <input type="text" class="form-control" value="" name="ramo">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Qtd Funcionários</div>
                                    </div>
                                    <input type="number" class="form-control" value="" name="qtd_funcionarios">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Data Fundação</div>
                                    </div>
                                    <input type="date" class="form-control" value="" name="data_fundacao">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Especialidades</div>
                                    </div>
                                    <input type="text" class="form-control" value="" name="especialidades">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Organização</div>
                                    </div>
                                    <select class="form-control" name="organizacao">
                                        <option value=""></option>
                                        <option value="Privada">Privada</option>
                                        <option value="Pública">Pública</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Links</div>
                                    </div>
                                    <input type="text" class="form-control" value="" name="links">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Telefone</div>
                                    </div>
                                    <input type="text" class="form-control" value="" name="telefone">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">CEP</div>
                                    </div>
                                    <input type="text" class="form-control" id="cep" value="" name="cep">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Endereço</div>
                                    </div>
                                    <input type="text" id="endereco" class="form-control" value="" name="endereco">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Estado</div>
                                    </div>
                                    <select name="estado_id" class="form-control <?php echo e($errors->has('estado_id') ? "is-invalid" : ""); ?>" id="estado" required>
                                        <option value="">Selecione o Estado</option>
                                        <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($estado->id); ?>"><?php echo e($estado->nome. ' - '. $estado->sigla ?? null); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Municipio</div>
                                    </div>
                                    <select name="municipio_id" class="form-control <?php echo e($errors->has('municipio_id') ? "is-invalid" : ""); ?>" id="municipio" disabled required>
                                        <option>Selecione o Estado</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Site</div>
                                    </div>
                                    <input type="text" class="form-control" value="" name="site">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Urls</div>
                                    </div>
                                    <input type="text" class="form-control" value="" name="url">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-check"></i> Cadastrar</button>
                        <a href="<?php echo e(route('admin.empresa.listar')); ?>" class="btn btn-danger btn-sm"><i class="fas fa-arrow-left"></i> Cancelar</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    $("#cep").change(function() {
        var cep = $("#cep").val();
        if (cep != '') {
            $.get('https://viacep.com.br/ws/' + cep + '/json/', function(data) {
                if (data != '') {
                    $("#endereco").val(data['logradouro']);
                } else {
                    $("#endereco").val('');
                }
            });
        } else {
            $("#endereco").val('');
        }
    });

    $("#estado").change(function() {
        if ($("#estado").val() != '') {
            $.ajax({
                type: 'get',
                url: '/empresa/vaga/getEstado/' + $("#estado").val(),
                beforeSend: function() {
                    $("#municipio").attr('disabled', false);
                    $("#municipio").append('<option selected>Carregando...</option>');
                },
                success: function(data) {
                    $("#municipio").empty();
                    data.forEach(function(valor, chave) {
                        $("#municipio").append("<option value='" + valor['id'] + "'>" + valor['nome'] + "</option>");
                    });
                }
            });
        } else {
            $("#municipio").empty();
            $("#municipio").append('<option selected>Selecione um estado</option>');
            $("#municipio").attr('disabled', true);
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views\admin\gerenciar_empresa\create.blade.php ENDPATH**/ ?>