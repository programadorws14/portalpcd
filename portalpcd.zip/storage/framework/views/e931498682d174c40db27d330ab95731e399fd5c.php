<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Empresas Recusadas</div>
                <div class="card-body">
                    <?php if(Session('success')): ?>
                    <div class="alert alert-success">
                        <b><i class="fas fa-check"></i> <?php echo e(Session('success')); ?></b>
                    </div>
                    <?php elseif(Session('error')): ?>
                    <div class="alert alert-danger">
                        <b><i class="fas fa-minus"></i> <?php echo e(Session('error')); ?></b>
                    </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="tabelaDinamica table table-striped table-bordered table-hover table-sm">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="6%">Logo</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Nome</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="10%">Ramo</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="10%">Qtd Funcionários</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="10%">Data Fund.</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="8%">Organização</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="8%">Status</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-middle"><?php if(!empty($empresa->logo)): ?>
                                        <img style="border:1px solid #ccc;" src="<?php echo e(asset('img/img-empresa.png')); ?>" width="60" height="60" class="img-fluid" alt="<?php echo e($empresa->nome); ?>" title="<?php echo e($empresa->nome); ?>">
                                        <?php else: ?>
                                        <img style="border:1px solid #ccc;" src="<?php echo e(asset('img/img-empresa.png')); ?>" width="60" height="60" class="img-fluid" alt="<?php echo e($empresa->nome); ?>" title="<?php echo e($empresa->nome); ?>">
                                        <?php endif; ?>
                                    </td>
                                    <td class="align-middle"><?php echo e($empresa->nome ?? null); ?></td>
                                    <td class="align-middle"><?php echo e($empresa->ramo ?? null); ?></td>
                                    <td class="align-middle"><?php echo e($empresa->qtd_funcionarios ?? null); ?></td>
                                    <td class="align-middle"><?php echo e(date('d/m/Y', strtotime($empresa->data_fundacao)) ?? null); ?></td>
                                    <td class="align-middle"><?php echo e($empresa->organizacao ?? null); ?></td>
                                    <td class="align-middle">
                                        <?php if($empresa->status == 3): ?>
                                        <span class="badge badge-danger">RECUSADA</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views\admin\gerenciar_empresa\list_recusadas.blade.php ENDPATH**/ ?>