<?php $__env->startSection('content'); ?>

<header class="section-heading pcd-container">
	<h1>Sua <strong>Empresa</strong></h1>
	<hr />
</header>

<div class="wrapper container-fluid">
	<div class="row">
		<div class="col-xs-12 col-md-3 profile__info">
			<?php if(!empty(Auth::guard('empresa')->user()->logo_empresa)): ?>
			<img src="<?php echo e(asset(Auth::guard('empresa')->user()->logo_empresa)); ?>" width="191" height="191" style="border-radius:100%;" alt="" />
			<?php else: ?>
			<img src="<?php echo e(asset('site/assets/images/profile-image.png')); ?>" alt="" />
			<?php endif; ?>
			<h2 class="profile__title"><?php echo e(Auth::guard('empresa')->user()->nome ?? null); ?> </h2>
			<p></p>
			<p class="profile__username"><?php echo e('/empresa/'.Auth::guard('empresa')->user()->nome_url ?? null); ?></p>
		</div>
	</div>
	<div class="row">
		<div class="col-md-3 col-xs-12">
			<section class="profile">
				<div class="profile__card">
					<section class="profile__section">
						<h2>
							Vagas Cadastradas <i class="fas fa-chevron-down"></i>
						</h2>
						<ul>
							<?php if(count($vagas) >= 1): ?>
							<?php $__currentLoopData = $vagas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($vaga->titulo ?? 'N/I'); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</ul>
					</section>
					<section class="profile__section">
						<h2>
							Lorem Ipsum <i class="fas fa-chevron-down"></i>
						</h2>
						<ul>
							<li><a href="#">Lorem Ipsum</a></li>
							<li>Lorem Ipsum</li>
							<li>Lorem Ipsum</li>
						</ul>
					</section>
				</div>
			</section>
		</div>
		<div class="col-md-8 col-md-offset-1 col-xs-12">

			<section class="dashboard-dados-vagas negative">

				<?php if(Session('success')): ?>
				<div class="alert alert-success" style="margin:20px 0; color:green;">
					<b><i class="fas fa-check"></i> <?php echo e(Session('success')); ?></b>
				</div>
				<?php elseif(Session('error')): ?>
				<div class="alert alert-danger" style="margin:20px 0; color:red;">
					<b><i class="fas fa-times-circle"></i> <?php echo e(Session('error')); ?></b>
				</div>
				<?php endif; ?>

				<div class="abas-area">
					<a class="aba active" data-open="vagas">Minhas vagas</a>
					<a class="aba" data-open="meus-dados">Meus dados</a>
				</div>
				<div class="content-aba">
					<div class="content vagas active">
						<ul>
							<?php if(count($vagas) > 0): ?>
							<?php $__currentLoopData = $vagas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li>
								<div class="infos-vaga">
									<span class="edit" onclick="modal_edit(<?php echo e($vaga->id); ?>)"><i class="fas fa-edit"></i></span>
									<span class="nome-vaga"><?php echo e($vaga->titulo ?? 'N/I'); ?></span>
									<span class="n-candidatos"><?php echo e(count($vaga->candidaturas)); ?> <i class="fas fa-user"></i></span>
									<?php if(!$vaga->pausar_vaga): ?>
									<span class="ativa">Ativa</span>
									<?php else: ?>
									<span class="pausada">Pausada</span>
									<?php endif; ?>
								</div>

								<?php if(count($vaga->candidaturas) > 0): ?>
								<a href="#" onclick="abrir_modal_ver_candidatos(<?php echo e($vaga->id); ?>)" class="cta ver-candidatos">Ver candidatos</a>
								<?php endif; ?>
							</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
							<?php echo e($vagas->links()); ?>

						</ul>
						<div class="area-botao">
							<button id="nova-vaga">Adicionar nova vaga</button>
							<a href="<?php echo e(route('exportar.candidatos.excel')); ?>" style="background-color:forestgreen; color:#FFF; padding:10px 15px; border-radius:20px; text-decoration:none; text-transform:uppercase; font-weight:bold; font-size:13px;" class="cta ver-candidatos">EXCEL VAGA + CANDIDATO</a>
						</div>

						<!---MODAL NOVA VAGA--->
						<?php echo $__env->make('empresa.dashboard.modal_nova_vaga', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

						<!--- MODAL EDIT--->
						<?php echo $__env->make('empresa.dashboard.modal_edit_vaga', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

						<!--- MODAL VER CANDIDATOS--->
						<?php echo $__env->make('empresa.dashboard.modal_ver_candidatos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


					</div>

					<div class="content meus-dados">
						<?php echo $__env->make('empresa.dashboard.form_meus_dados', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</div>
			</section>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
	$("#emailPerfil").change(function() {
		var email = $("#emailPerfil").val();
		if (email != '') {
			$.get(route('empres.verifica.email', email), function(data) {
				if (data.status == 'sucesso') {
					$("#emailPerfil").css('border', '1px solid red')
					$("#msgErroEmail").html('E-mail já existe, tente outro').fadeIn('slow');
					$("#atualizarPerfil").prop('disabled', true);
				} else {
					$("#emailPerfil").css('border', '1px solid #eeeeee')
					$("#msgErroEmail").fadeOut('slow');
					$("#atualizarPerfil").prop('disabled', false);
				}
			});
		}
	});


	$("#cep").change(function() {
		var cep = $("#cep").val();
		if (cep != '') {
			$.get('https://viacep.com.br/ws/' + cep + '/json/', function(data) {
				if (data != '') {
					$("#rua").val(data['logradouro']);
					$("#complemento").val(data['complemento']);
					$("#cidade").val(data['localidade']);
					$("#bairro").val(data['bairro']);
					$("#estado").val(data['uf']);
				} else {
					$("#rua").val('');
					$("#complemento").val('');
					$("#cidade").val('');
					$("#bairro").val('');
					$("#estado").val('');
				}
			});
		} else {
			$("#rua").val('');
			$("#complemento").val('');
			$("#cidade").val('');
			$("#bairro").val('');
			$("#estado").val('');
		}
	});

	$("#cep_vaga").change(function() {
		var cep = $("#cep_vaga").val();
		if (cep != '') {
			$.get('https://viacep.com.br/ws/' + cep + '/json/', function(data) {
				if (data != '') {
					$("#rua_vaga").val(data['logradouro']);
					$("#complemento_vaga").val(data['complemento']);
					$("#cidade_vaga").val(data['localidade']);
					$("#bairro_vaga").val(data['bairro']);
					$("#estado_vaga").val(data['uf']);
				} else {
					$("#rua_vaga").val('');
					$("#complemento_vaga").val('');
					$("#cidade_vaga").val('');
					$("#bairro_vaga").val('');
					$("#estado_vaga").val('');
				}
			});
		} else {
			$("#rua_vaga").val('');
			$("#complemento_vaga").val('');
			$("#cidade_vaga").val('');
			$("#bairro_vaga").val('');
			$("#estado_vaga").val('');
		}
	});

	$("#cep_edit_vaga").change(function() {
		var cep = $("#cep_edit_vaga").val();
		if (cep != '') {
			$.get('https://viacep.com.br/ws/' + cep + '/json/', function(data) {
				if (data != '') {
					$("#rua_edit_vaga").val(data['logradouro']);
					$("#complemento_edit_vaga").val(data['complemento']);
					$("#cidade_edit_vaga").val(data['localidade']);
					$("#bairro_edit_vaga").val(data['bairro']);
					$("#estado_edit_vaga").val(data['uf']);
				} else {
					$("#rua_edit_vaga").val('');
					$("#complemento_edit_vaga").val('');
					$("#cidade_edit_vaga").val('');
					$("#bairro_edit_vaga").val('');
					$("#estado_edit_vaga").val('');
				}
			});
		} else {
			$("#rua_edit_vaga").val('');
			$("#complemento_edit_vaga").val('');
			$("#cidade_edit_vaga").val('');
			$("#bairro_edit_vaga").val('');
			$("#estado_edit_vaga").val('');
		}
	});

	function delLinks(id) {
		// 
		$.get(route('empresa.delLinks', id), function(data) {
			if (data.status == 'success') {
				$("#" + id).hide();
			}
		});
	}

	/** Validação salario de, salario ate */
	$("#combinar_salario").click(function() {
		if ($("#combinar_salario").is(':checked')) {
			$("#faixa_de").prop('disabled', true);
			$("#faixa_ate").prop('disabled', true);
			$("#faixa_de").prop('required', false);
			$("#faixa_ate").prop('required', false);
		} else {
			$("#faixa_de").prop('disabled', false);
			$("#faixa_ate").prop('disabled', false);

			$("#faixa_de").prop('required', true);
			$("#faixa_ate").prop('required', true);
		}
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\jobs\portalpcd\resources\views/empresa/dashboard/index.blade.php ENDPATH**/ ?>