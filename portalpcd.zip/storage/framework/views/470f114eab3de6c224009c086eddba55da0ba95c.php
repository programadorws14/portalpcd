<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php if(Session('success')): ?>
            <div class="alert alert-success">
                <b><i class="fas fa-check"></i> <?php echo e(Session('success')); ?></b>
            </div>
            <?php elseif(Session('error')): ?>
            <div class="alert alert-danger">
                <b><i class="fas fa-minus"></i> <?php echo e(Session('error')); ?></b>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('admin.paginas.update')); ?>" method="POSt" enctype="multipart/form-data">
                <?php echo e(method_field('PUT')); ?>

                <div class="card">
                    <div class="card-header">Editar Página: <b><?php echo e($edit->titulo ?? null); ?></b></div>
                    <div class="card-body">
                        <div class="row">
                            <?php echo $__env->make('admin.gerenciar_paginas._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i> Atualizar</button>
                        <a href="<?php echo e(route('admin.paginas.index')); ?>" class="btn btn-danger btn-sm"><i class="fas fa-arrow-left"></i> Cancelar</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\jobs\portalpcd\resources\views/admin/gerenciar_paginas/edit.blade.php ENDPATH**/ ?>