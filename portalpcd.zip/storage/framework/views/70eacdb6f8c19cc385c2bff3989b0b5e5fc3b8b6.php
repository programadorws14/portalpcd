<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Vagas Recusadas</div>
                <div class="card-body">
                    <?php if(Session('success')): ?>
                    <div class="alert alert-success">
                        <b><i class="fas fa-check"></i> <?php echo e(Session('success')); ?></b>
                    </div>
                    <?php elseif(Session('error')): ?>
                    <div class="alert alert-danger">
                        <b><i class="fas fa-minus"></i> <?php echo e(Session('error')); ?></b>
                    </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="tabelaDinamica table table-striped table-bordered table-hover table-sm">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="10%">Dt. Soli.</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="20%">Titulo</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="10%">Descrição</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="4%">Qtd Vagas</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="8%">Empresa</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="8%">Endereço</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Estado</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Municipio</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Status</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php $__currentLoopData = $vagas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-middle"><?php echo e(date('d/m/Y', strtotime($vaga->created_at)) ?? null); ?></td>
                                    <td class="align-middle"><?php echo e($vaga->titulo ?? null); ?></td>
                                    <td class="align-middle"><?php echo e($vaga->descricao ?? null); ?></td>
                                    <td class="align-middle"><?php echo e($vaga->qtd_vagas ?? null); ?></td>
                                    <td class="align-middle"><?php echo e($vaga->user[0]->nome ?? null); ?></td>
                                    <td class="align-middle"><?php echo e($vaga->endereco?? null); ?></td>
                                    <td class="align-middle"><?php echo e($vaga->estado[0]->nome ?? null); ?></td>
                                    <td class="align-middle"><?php echo e($vaga->municipio[0]->nome ?? null); ?></td>

                                    <td class="align-middle">
                                        <span class="badge badge-danger">RECUSADA</span>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views\admin\gerenciar_vaga\recusadas.blade.php ENDPATH**/ ?>