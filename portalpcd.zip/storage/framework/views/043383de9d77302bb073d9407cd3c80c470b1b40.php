<table>
    <thead>
        <tr>
            <th>Nome</th>
            <th>E-mail</th>
            <th>Data de Criação</th>
        </tr>
    </thead>
    <tbody>
        <?php if(count($newsletters) > 0): ?>
            <?php $__currentLoopData = $newsletters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newletter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="align-middle p-2"><?php echo e($newletter->nome ?? 'N/I'); ?></td>
                    <td class="align-middle p-2"><?php echo e($newletter->email ?? 'N/I'); ?></td>
                    <td class="align-middle p-2"><?php echo e(date('d/m/Y', strtotime($newletter->created_at)) ?? 'N/I'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>
<?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views/admin/gerenciar_newsletter/_list_excel.blade.php ENDPATH**/ ?>