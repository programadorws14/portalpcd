<?php $__env->startSection('content'); ?>

<header class="section-heading pcd-container">
    <h1>PCD / <strong><?php echo e($page->titulo); ?></strong></h1>
    <hr />
</header>

<div class="wrapper container-fluid">
    <div class="row">
        <div class="col-md-12 col-xs-12">
            <section class="descricao-vaga negative page">
                <div class="content-descricao-vaga">
                    <div class="content">
                        <small style="margin-bottom:20px; float:left; width:100%;    color:#CCC;">Data: <?php echo e(date('d/m/Y', strtotime($page->created_at))); ?></small>
                        <p><?php echo $page->conteudo; ?></p>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\jobs\portalpcd\resources\views/site/pagina/page.blade.php ENDPATH**/ ?>