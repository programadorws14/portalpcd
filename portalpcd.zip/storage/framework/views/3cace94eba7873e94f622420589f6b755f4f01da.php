<?php $__env->startSection('content'); ?>
<section class="login">
    <div class="login-container">
        <header class="section-heading  pcd-container">
            <h1><strong>Login</strong></h1>
            <hr />
        </header>
        <div class="forms-area">
            <form action="<?php echo e(route('admin.store.login')); ?>" style="margin:0 auto !important;" class="default-form" id="candidato" method="POST">
                <?php echo csrf_field(); ?>
                <h2 class="form-title">Sou Administrador - Quero me logar</h2>
                <input type="email" placeholder="Digite seu e-mail" name="email">
                <input type="password" placeholder="Digite sua senha" name="password">
                <input type="submit" value="Entrar">
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\jobs\portalpcd\resources\views/admin/login/index.blade.php ENDPATH**/ ?>