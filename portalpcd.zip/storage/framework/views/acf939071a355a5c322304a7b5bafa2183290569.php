<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <form action="<?php echo e(route('admin.gerenciar.empresa.store')); ?>" method="POST" enctype="multipart/form-data">
            <div class="card">
                <div class="card-header">Cadastrar Empresa</div>
                    <div class="card-body">
                        <?php if(Session('success')): ?>
                        <div class="alert alert-success">
                            <b><i class="fas fa-check"></i> <?php echo e(Session('success')); ?></b>
                        </div>
                        <?php elseif(Session('error')): ?>
                        <div class="alert alert-danger">
                            <b><i class="fas fa-minus"></i> <?php echo e(Session('error')); ?></b>
                        </div>
                        <?php endif; ?>
                        <?php echo $__env->make('admin.gerenciar_empresa._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="card-footer">
                        <button type="submit" id="bntSubmit" class="btn btn-success"><i class="fas fa-save"></i> Salvar</button>
                        <a href="<?php echo e(route('admin.gerenciar.empresas')); ?>" class="btn btn-danger"><i class="fas fa-arrow-left"></i> Cancelar</a>
                    </div>
               
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $("#emailPerfil").change(function() {
        var email = $("#emailPerfil").val();
        if (email != '') {
            $.get(route('empres.verifica.email', email), function(data) {
                if (data.status == 'sucesso') {
                    $("#emailPerfil").addClass('is-invalid')
                    $("#msgErroMail").html('E-mail já existe, tente outro').fadeIn('slow');
                    $("#bntSubmit").prop('disabled', true);
                } else if (data.status == 'error') {
                    $("#emailPerfil").removeClass('is-invalid')
                    $("#msgErroMail").fadeOut('slow');
                    $("#bntSubmit").prop('disabled', false);
                }
            });
        }
    });

    $("#cep").change(function() {
        var cep = $("#cep").val();
        if (cep != '') {
            $.get('https://viacep.com.br/ws/' + cep + '/json/', function(data) {
                if (data != '') {
                    $("#rua").val(data['logradouro']).prop('disabled', false);
                    $("#numero").prop('disabled', false);
                    $("#complemento").val(data['complemento']).prop('disabled', false);
                    $("#cidade").val(data['localidade']).prop('disabled', false);
                    $("#bairro").val(data['bairro']).prop('disabled', false);
                    $("#estado").val(data['uf']).prop('disabled', false);
                } else {
                    $("#rua").val('').prop('disabled', true);
                    $("#numero").prop('disabled', true);
                    $("#complemento").val('').prop('disabled', true);
                    $("#cidade").val('').prop('disabled', true);
                    $("#bairro").val('').prop('disabled', true);
                    $("#estado").val('').prop('disabled', true);
                }
            });
        } else {
            $("#rua").val('').prop('disabled', true);
            $("#numero").prop('disabled', true);
            $("#complemento").val('').prop('disabled', true);
            $("#cidade").val('').prop('disabled', true);
            $("#bairro").val('').prop('disabled', true);
            $("#estado").val('').prop('disabled', true);
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views/admin/gerenciar_empresa/create.blade.php ENDPATH**/ ?>