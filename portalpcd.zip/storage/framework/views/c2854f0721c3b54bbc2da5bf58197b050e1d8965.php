<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php if(Session('success')): ?>
            <div class="alert alert-success">
                <b><i class="fas fa-check"></i> <?php echo e(Session('success')); ?></b>
            </div>
            <?php elseif(Session('error')): ?>
            <div class="alert alert-danger">
                <b><i class="fas fa-minus"></i> <?php echo e(Session('error')); ?></b>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('admin.config.profissao.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-header">Nova Profissão</div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-9">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Descrição</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e(old('descricao')); ?>" name="descricao">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Status</div>
                                    </div>
                                    <select class="form-control" name="status">
                                        <option value="">Selectione o status</option>
                                        <option value="1">Ativo</option>
                                        <option value="2">Inativo</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-check"></i> Cadastrar</button>
                        <a href="<?php echo e(route('admin.config.profissao.index')); ?>" class="btn btn-danger btn-sm"><i class="fas fa-arrow-left"></i> Cancelar</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php echo $__env->make('admin.config.profissao.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views\admin\config\profissao\index.blade.php ENDPATH**/ ?>