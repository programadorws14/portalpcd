<?php $__env->startSection('content'); ?>
<div class="container-fluid mb-5">
    <div class="row justify-content-center">
        <div class="col-md-3">
            <div class="card text-white bg-primary mb-3">
                <div class="card-header"><b>EMPRESAS</b></div>
                <div class="card-body">
                    <h1 class="card-title"><i class="fas fa-building"></i> <?php echo e(count($countEmp) ?? 'N/I'); ?></h1>
                    <p class="card-text">Cadastradas</p>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-white bg-secondary mb-3">
                <div class="card-header"><b>USUÁRIOS</b></div>
                <div class="card-body">
                    <h1 class="card-title"><i class="fas fa-users"></i> <?php echo e(count($countUsu) ?? 'N/I'); ?></h1>
                    <p class="card-text">Cadastradas</p>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-white bg-success mb-3">
                <div class="card-header"><b>VAGAS</b></div>
                <div class="card-body">
                    <h1 class="card-title"><i class="fas fa-briefcase"></i> <?php echo e(count($countVag) ?? 'N/I'); ?></h1>
                    <p class="card-text">Cadastradas</p>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-white bg-dark mb-3">
                <div class="card-header"><b>POSTS</b></div>
                <div class="card-body">
                    <h1 class="card-title"><i class="fas fa-blog"></i> <?php echo e(count($countPos) ?? 'N/I'); ?></h1>
                    <p class="card-text">Cadastrados</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mb-5">
    <div class="row">
        <div class="col-md-6 mb-5">
            <div class="card">
                <h5 class="card-header">Últimos Usuários</h5>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="tabelaDinamica table table-bordered  table-sm">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="5%">Foto</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Nome</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Rua</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Cidade</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Estado</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Ação</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php if(count($usuarios) > 0): ?>
                                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="align-middle p-2">
                                                <?php if(!empty($usuario->foto)): ?>
                                                <img src="<?php echo e(asset($usuario->foto)); ?>" width="60" height="60" style="border-radius:100%;" alt="" />
                                                <?php else: ?>
                                                <img src="<?php echo e(asset('site/assets/images/profile-image.png')); ?>" width="60" height="60" alt="" />
                                                <?php endif; ?>
                                            </td>
                                            <td class="align-middle p-2"><?php echo e($usuario->nome ?? 'N/I'); ?></td>
                                            <td class="align-middle p-2"><?php echo e($usuario->rua ?? 'N/I'); ?></td>
                                            <td class="align-middle p-2"><?php echo e($usuario->cidade ?? 'N/I'); ?></td>
                                            <td class="align-middle p-2"><?php echo e($usuario->estado ?? 'N/I'); ?></td>
                                            <td class="align-middle p-2">
                                                <a href="<?php echo e(route('admin.gerenciar.edit', $usuario->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a>
                                                <a href="<?php echo e(route('admin.gerenciar.deletar', $usuario->id)); ?>" onClick="return confirm('Deseja mesmo deletar ?')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-5">
            <div class="card">
                <h5 class="card-header">Últimos Empresas</h5>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="tabelaDinamica table table-bordered  table-sm">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="5%">Foto</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Nome</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Rua</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Cidade</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Estado</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Ação</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php if(count($empresas) > 0): ?>
                                    <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="align-middle p-2">
                                                <?php if(!empty($empresa->logo_empresa)): ?>
                                                <img src="<?php echo e(asset($empresa->logo_empresa)); ?>" width="60" height="60" style="border-radius:100%;" alt="" />
                                                <?php else: ?>
                                                <img src="<?php echo e(asset('site/assets/images/profile-image.png')); ?>" width="60" height="60" alt="" />
                                                <?php endif; ?>
                                            </td>
                                            <td class="align-middle p-2"><?php echo e($empresa->nome ?? 'N/I'); ?></td>
                                            <td class="align-middle p-2"><?php echo e($empresa->rua ?? 'N/I'); ?></td>
                                            <td class="align-middle p-2"><?php echo e($empresa->cidade ?? 'N/I'); ?></td>
                                            <td class="align-middle p-2"><?php echo e($empresa->estado ?? 'N/I'); ?></td>
                                            <td class="align-middle p-2">
                                                <a href="<?php echo e(route('admin.gerenciar.empresa.edit', $empresa->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a>
                                                <a href="" onClick="return confirm('Deseja mesmo deletar ?')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-5">
            <div class="card">
                <h5 class="card-header">Últimos Vagas</h5>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="tabelaDinamica table table-bordered  table-sm">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="5%">Foto</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Empresa</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Vaga</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Candidaturas</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Estado</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Ação</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php if(count($vagas) > 0): ?>
                                    <?php $__currentLoopData = $vagas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="align-middle p-2">
                                                <?php if(!empty($vaga->empresa->logo_empresa)): ?>
                                                <img src="<?php echo e(asset($vaga->empresa->logo_empresa)); ?>" width="60" height="60" style="border-radius:100%;" alt="" />
                                                <?php else: ?>
                                                <img src="<?php echo e(asset('site/assets/images/profile-image.png')); ?>" width="60" height="60" alt="" />
                                                <?php endif; ?>
                                            </td>
                                            <td class="align-middle p-2"><?php echo e($vaga->empresa->nome ?? 'N/I'); ?></td>
                                            <td class="align-middle p-2"><?php echo e($vaga->titulo ?? 'N/I'); ?></td>
                                            <td class="align-middle p-2"><?php echo e(count($vaga->candidaturas) ?? 'N/I'); ?></td>
                                            <td class="align-middle p-2"><?php echo e($vaga->estado ?? 'N/I'); ?></td>
                                            <td class="align-middle p-2">
                                                <a href="<?php echo e(route('admin.gerenciar.vaga.edit', $vaga->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a>
                                                <a href="#" onClick="return confirm('Deseja mesmo deletar ?')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-5">
            <div class="card">
                <h5 class="card-header">Últimos Posts Blog</h5>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="tabelaDinamica table table-bordered  table-sm">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="5%">Foto</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Titulo</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Categoria</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Data</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Ação</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php if(count($posts) > 0): ?>
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="align-middle p-2">
                                                <?php if(!empty($post->capa)): ?>
                                                <img src="<?php echo e(asset($post->capa)); ?>" width="60" height="60" style="border-radius:100%;" alt="" />
                                                <?php else: ?>
                                                <img src="<?php echo e(asset('site/assets/images/profile-image.png')); ?>" width="60" height="60" alt="" />
                                                <?php endif; ?>
                                            </td>
                                            <td class="align-middle p-2"><?php echo e($post->titulo ?? 'N/I'); ?></td>
                                            <td class="align-middle p-2"><?php echo e($post->categoria->descricao ?? 'N/I'); ?></td>
                                            <td class="align-middle p-2"><?php echo e(date('d/m/Y', strtotime($post->created_at)) ?? 'N/I'); ?></td>
                                            <td class="align-middle p-2">
                                                <a href="<?php echo e(route('admin.blog.categoria.edit', $vaga->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a>
                                                <a href="<?php echo e(route('admin.blog.categoria.delete', $vaga->id)); ?>" onClick="return confirm('Deseja mesmo deletar ?')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\jobs\portalpcd\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>