<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Recusadas</div>
                <div class="card-body">
                    <?php if(Session('success')): ?>
                    <div class="alert alert-success">
                        <b><i class="fas fa-check"></i> <?php echo e(Session('success')); ?></b>
                    </div>
                    <?php elseif(Session('error')): ?>
                    <div class="alert alert-danger">
                        <b><i class="fas fa-minus"></i> <?php echo e(Session('error')); ?></b>
                    </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="tabelaDinamica table table-striped table-bordered table-hover table-sm">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Por</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Salário</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Status</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Estado</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Municipio</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Endereço</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Titulo</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Qtd Vagas</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Aprovação</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Observações</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Data</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php $__currentLoopData = $vagas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(Auth::user()->nome ?? null); ?></td>
                                    <td><?php echo e(( $vaga->salario ? 'R$ '. number_format( $vaga->salario, 2, ',', '.') : 'A Combinar')); ?></td>
                                    <td>
                                        <?php if($vaga->status == 1): ?>
                                        Ativo
                                        <?php else: ?>
                                        Inativo
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($vaga->estado[0]->nome ?? null); ?></td>
                                    <td><?php echo e($vaga->municipio[0]->nome ?? null); ?></td>
                                    <td><?php echo e($vaga->endereco ?? null); ?></td>
                                    <td><?php echo e($vaga->titulo ?? null); ?></td>
                                    <td><?php echo e($vaga->qtd_vagas ?? null); ?></td>
                                    <td>
                                        <?php if($vaga->aprovacao_user_id == null): ?>
                                        <span class="badge badge-warning">Aguardando Aprovação</span>
                                        <?php elseif($vaga->status == 1 && $vaga->aprovacao_user_id != null): ?>
                                        <span class="badge badge-success">Aprovado</span>
                                        <?php elseif($vaga->status == 3 && $vaga->aprovacao_user_id != null): ?>
                                        <span class="badge badge-danger">Recusado</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($vaga->info_aprovacao_user_id ?? null); ?></td>
                                    <td><?php echo e(date('d/m/Y h:i:s', strtotime($vaga->updated_at)) ?? null); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('empresa.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views\empresa\vagas\list_recusada.blade.php ENDPATH**/ ?>