<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header"></b>Postagens</b>
            <a href="<?php echo e(route('admin.blog.post.create')); ?>" class="btn btn-success btn-sm"><i class="fas fa-plus"></i> Novo Post</a>
        </div>
        <div class="card-body">
            <?php if(Session('success')): ?>
            <div class="alert alert-success">
                <b><i class="fas fa-check"></i> <?php echo e(Session('success')); ?></b>
            </div>
            <?php elseif(Session('error')): ?>
            <div class="alert alert-danger">
                <b><i class="fas fa-minus"></i> <?php echo e(Session('error')); ?></b>
            </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="tabelaDinamica table table-bordered table-sm">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="10%">Capa</th>
                            <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="40%">Titulo</th>
                            <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="10%">Categoria</th>
                            <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="8%">Visitas</th>
                            <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="10%">Autor</th>
                            <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="13%">Ação</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="align-middle">
                                <?php if(!empty($post->capa)): ?>
                                <img style="border:1px solid #ccc;" src="<?php echo e(asset($post->capa)); ?>" width="120" height="120" class="img-fluid" alt="<?php echo e($post->titulo); ?>" title="<?php echo e($post->titulo); ?>">
                                <?php else: ?>
                                <img style="border:1px solid #ccc;" src="<?php echo e(asset('img/img-empresa.png')); ?>" width="120" height="120" class="img-fluid" alt="<?php echo e($post->titulo); ?>" title="<?php echo e($post->titulo); ?>">
                                <?php endif; ?>
                            </td>
                            <td class="align-middle"><?php echo e($post->titulo ?? null); ?></td>
                            <td class="align-middle"><?php echo e($post->categoria[0]->descricao ?? null); ?></td>
                            <td class="align-middle">12</td>
                            <td class="align-middle"><?php echo e($post->autor[0]->nome ?? null); ?></td>
                            <td class="align-middle">
                                <a href="#" class="btn btn-warning btn-sm"><i class="fas fa-eye"></i></a>
                                <a href="<?php echo e(route('admin.blog.post.edit', $post->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a>
                                <a href="<?php echo e(route('admin.blog.post.delete', $post->id)); ?>" onClick="return confirm('Deseja mesmo deletar ?')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views\admin\blog\index.blade.php ENDPATH**/ ?>