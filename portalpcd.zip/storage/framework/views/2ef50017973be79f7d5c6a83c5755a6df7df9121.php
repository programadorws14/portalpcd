<?php echo csrf_field(); ?>
<?php if(!empty($edit)): ?>
<input type="hidden" value="<?php echo e($edit->id ?? null); ?>" name="id">
<?php endif; ?>

<div class="col-md-12">
    <div class="input-group mb-4">
        <div class="input-group-prepend">
            <div class="input-group-text">Titulo</div>
        </div>
        <input type="text" class="form-control" value="<?php if(!empty($edit)): ?> <?php echo e($edit->titulo); ?> <?php else: ?> <?php echo e(old('titulo')); ?> <?php endif; ?>" name="titulo">
    </div>
</div>

<div class="col-md-12 mb-3">
    <textarea type="text" class="editor form-control" rows="15" name="conteudo" placeholder="Conteúdo"><?php if(!empty($edit)): ?> <?php echo e($edit->conteudo); ?> <?php else: ?> <?php echo e(old('conteudo')); ?> <?php endif; ?></textarea>
</div>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.tiny.cloud/1/lqk0zhhopgun65yfm2oh7o5wgu8lyeqseadx1t24nughq8gz/tinymce/5/tinymce.min.js"></script>
<script>
    tinymce.init({
        selector: '.editor',
        menubar: false,
        plugins: [
            'advlist autolink lists link image charmap print preview anchor',
            'searchreplace visualblocks code fullscreen',
            'insertdatetime media table paste code help wordcount'
        ],
        toolbar: 'undo redo | formatselect | bold italic backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
        content_css: [
            '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
            '//www.tiny.cloud/css/codepen.min.css'
        ]
    });
</script>
<?php $__env->stopSection(); ?><?php /**PATH C:\wamp64\www\jobs\portalpcd\resources\views/admin/gerenciar_paginas/_form.blade.php ENDPATH**/ ?>