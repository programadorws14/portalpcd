<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php if(Session('success')): ?>
            <div class="alert alert-success">
                <b><i class="fas fa-check"></i> <?php echo e(Session('success')); ?></b>
            </div>
            <?php elseif(Session('error')): ?>
            <div class="alert alert-danger">
                <b><i class="fas fa-minus"></i> <?php echo e(Session('error')); ?></b>
            </div>
            <?php endif; ?>

            <div class="col-md-12 mb-3">
                <?php if(!empty($edit->logo)): ?>
                <img style="border:1px solid #ccc;" src="<?php echo e(asset($edit->logo)); ?>" width="120" height="120 " class="img-fluid" alt="<?php echo e($edit->nome); ?>" title="<?php echo e($edit->nome); ?>">
                <?php else: ?>
                <img style="border:1px solid #ccc;" src="<?php echo e(asset('img/img-empresa.png')); ?>" width="120" height="120" class="img-fluid" alt="<?php echo e($edit->nome); ?>" title="<?php echo e($edit->nome); ?>">
                <?php endif; ?>
            </div>
            <form action="<?php echo e(route('admin.empresa.update')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($edit->id); ?>">
                <div class="card">
                    <div class="card-header">Editando: <b><?php echo e($edit->nome); ?></b></div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Logotipo</div>
                                    </div>
                                    <input type="file" class="form-control" value="" accept="image/*" name="logo">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Nome</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->nome ?? null); ?>" name="nome">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">E-mail</div>
                                    </div>
                                    <input type="email" class="form-control" value="<?php echo e($edit->email ?? null); ?>" name="email">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Senha</div>
                                    </div>
                                    <input type="password" class="form-control" value="" name="password">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Descrição</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->descricao ?? null); ?>" name="descricao">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Ramo</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->ramo ?? null); ?>" name="ramo">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Qtd Funcionários</div>
                                    </div>
                                    <input type="number" class="form-control" value="<?php echo e($edit->qtd_funcionarios ?? null); ?>" name="qtd_funcionarios">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Data Fundação</div>
                                    </div>
                                    <input type="date" class="form-control" value="<?php echo e(date('Y-m-d', strtotime($edit->data_fundacao)) ?? null); ?>" name="data_fundacao">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Especialidades</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->especialidades ?? null); ?>" name="especialidades">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Organização</div>
                                    </div>
                                    <select class="form-control" name="organizacao">
                                        <option value="">Selecione organização</option>
                                        <option <?php if($edit->organizacao == 'Privada'): ?> selected <?php endif; ?> value="Privada">Privada</option>
                                        <option <?php if($edit->organizacao == 'Pública'): ?> selected <?php endif; ?> value="Pública">Pública</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Links</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->links ?? null); ?>" name="links">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Telefone</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->telefone ?? null); ?>" name="telefone">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">CEP</div>
                                    </div>
                                    <input type="text" class="form-control" id="cep" value="<?php echo e($edit->cep ?? null); ?>" name="cep">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Endereço</div>
                                    </div>
                                    <input type="text" id="endereco" class="form-control" value="<?php echo e($edit->endereco ?? null); ?>" name="endereco">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Estado</div>
                                    </div>
                                    <select name="estado_id" class="form-control <?php echo e($errors->has('estado_id') ? "is-invalid" : ""); ?>" id="estado" required>
                                        <option value="">Selecione o Estado</option>
                                        <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($estado->id == $edit->estado_id): ?> selected <?php endif; ?> value="<?php echo e($estado->id); ?>"><?php echo e($estado->nome. ' - '. $estado->sigla ?? null); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Municipio</div>
                                    </div>
                                    <select name="municipio_id" class="form-control <?php echo e($errors->has('municipio_id') ? "is-invalid" : ""); ?>" id="municipio" required>
                                        <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($municipio->id == $edit->municipio_id): ?> selected <?php endif; ?> value="<?php echo e($municipio->id); ?>"><?php echo e($municipio->nome ?? null); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Site</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->site ?? null); ?>" name="site">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Urls</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->url ?? null); ?>" name="url">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i> Editar</button>
                        <a href="<?php echo e(route('admin.empresa.listar')); ?>" class="btn btn-danger btn-sm"><i class="fas fa-arrow-left"></i> Cancelar</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    $("#cep").change(function() {
        var cep = $("#cep").val();
        if (cep != '') {
            $.get('https://viacep.com.br/ws/' + cep + '/json/', function(data) {
                if (data != '') {
                    $("#endereco").val(data['logradouro']);
                } else {
                    $("#endereco").val('');
                }
            });
        } else {
            $("#endereco").val('');
        }
    });

    $("#estado").change(function() {
        if ($("#estado").val() != '') {
            $.ajax({
                type: 'get',
                url: '/empresa/vaga/getEstado/' + $("#estado").val(),
                beforeSend: function() {
                    $("#municipio").attr('disabled', false);
                    $("#municipio").append('<option selected>Carregando...</option>');
                },
                success: function(data) {
                    $("#municipio").empty();
                    data.forEach(function(valor, chave) {
                        $("#municipio").append("<option value='" + valor['id'] + "'>" + valor['nome'] + "</option>");
                    });
                }
            });
        } else {
            $("#municipio").empty();
            $("#municipio").append('<option selected>Selecione um estado</option>');
            $("#municipio").attr('disabled', true);
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views\admin\gerenciar_empresa\edit.blade.php ENDPATH**/ ?>