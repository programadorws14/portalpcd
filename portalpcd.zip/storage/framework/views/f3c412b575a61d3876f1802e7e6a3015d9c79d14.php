<?php $__env->startSection('content'); ?>
<section class="search-form__container">
    <h1 class="search-form__title hide show-md">
        DIFÍCIL DE ENCONTRAR TRABALHO?
        <br />
        <strong>AQUI FICA MAIS PERTO DO SEU OBJETIVO</strong>
    </h1>
    <form action="<?php echo e(route('site.vagas')); ?>" method="get" class="search-form">
        <!-- <input type="text" name="job-title" placeholder="Digite o Cargo ou Área Profissional" /> -->
        <select class="select2" name="pesquisa-text" placeholder="Vagas" place style="width:35%; height: auto !important;">
            <option value="">Selecione a vaga</option>
            <?php if(count($vagas) > 0): ?>
            <?php $__currentLoopData = $vagas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($vaga->titulo); ?>"><?php echo e($vaga->titulo); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
        <p class="search-form__helper-text">Exemplos: Gerente, UX, Telefonista</p>

        <div class="search-form__breaker"></div>

        <!-- <input type="text" name="job-title" placeholder="Digite o Cargo ou Área Profissional" /> -->
        <select class="select2" name="estado[]" placeholder="" style=" width:35%; height: auto !important;">
            <option value="">Selecione o estado</option>
            <?php if(count($estados) > 0): ?>
            <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($estado->estado); ?>"><?php echo e($estado->estado); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
        <p class="search-form__helper-text">
            Exemplos: Ribeirão Preto, São Paulo, Rio de Janeiro
        </p>

        <div class="search-form__breaker"></div>

        <button type="submit" class="search-form__submit">Buscar Vagas</button>
    </form>
</section>

<header class="section-heading  pcd-container">
    <h1>Principais <strong>VAGAS</strong></h1>
    <hr />
    <a href="<?php echo e(route('site.vagas')); ?>">Confira todas as vagas</a>
</header>

<section class="jobs-card__container  pcd-container">
    <div class="row search-form__row">
        <?php if(count($vagas) <= 0): ?> <div class="alert alert-warning">
            <p>Ainda não temos vagas cadastradas!</p>
    </div>
    <?php else: ?>
    <?php $__currentLoopData = $vagas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-xs-12 col-md-4" style="margin-top:25px;">
        <article class="jobs-card">
            <section class="jobs-card__header">
                <div class="jobs-card__image">

                    <?php if(!empty($vaga->empresa->logo_empresa)): ?>
                    <img src="<?php echo e(asset($vaga->empresa->logo_empresa)); ?>" width="90" height="90" alt="<?php echo e($vaga->empresa->nome ?? null); ?>" />
                    <?php else: ?>
                    <img src="<?php echo e(asset('img/img-empresa.png')); ?>" width="90" height="90" alt="<?php echo e($vaga->empresa->nome ?? null); ?>" />
                    <?php endif; ?>

                </div>
                <div class="jobs-card__description">
                    <h2 class="jobs-card__title"><a href="<?php echo e(route('site.vagas.show', $vaga->id)); ?>"><?php echo e(substr($vaga->titulo, 0, 20) ?? null); ?></a></h2>
                    <h4 class="jobs-card__subtitle"><?php echo e(substr($vaga->descricao_vaga, 0, 65) ?? null); ?></h4>
                </div>
            </section>
            <footer class="jobs-card__footer">
                <p class="jobs-card__location">
                    <i class="fas fa-location-arrow"></i>&nbsp; <?php echo e($vaga->cidade ?? null); ?> - <?php echo e($vaga->estado ?? null); ?>

                </p>
                <p class="jobs-card__date">
                    <i class="fas fa-calendar"></i>&nbsp; Publicado em: <?php echo e(date('d/m/Y', strtotime($vaga->created_at)) ?? null); ?>

                </p>
            </footer>
        </article>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <div class="cards-vermais row"></div>

    </div>
    <div class="row ">
        <div class="col-xs-12 hide show-md">
            <button type="button" class="jobs-card__see-more">Ver Mais</button>
        </div>
    </div>
</section>

<section class="submit-cv-cta  pcd-container">
    <div class="submit-cv-cta__description">
        <h1>Cadastre Agora seu CV</h1>
        <h2>
            Cadastre o seu CV e candidate-se as vagas das melhores empresas do Brasil
        </h2>
    </div>
    <a href="#">Cadastre Aqui</a>
</section>

<header class="section-heading  pcd-container">
    <h1>As Últimas do <strong>BLOG</strong></h1>
    <hr />
    <a href="#">Confira todas as notícias</a>
</header>

<section class="blog-post__container  pcd-container">
    <div class="row blog-post__row">

        <?php if(count($posts) > 0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xs-12 col-md-4">
            <article class="blog-post">
                <section class="blog-post__header">
                    <div class="blog-post__image">
                        <?php if(!empty($post->capa)): ?>
                        <img src="<?php echo e(asset($post->capa)); ?>" width="160" height="160" alt="<?php echo e($post->capa ?? null); ?>" style="border-radius:100%;" />
                        <?php else: ?>
                        <img src="<?php echo e(asset('site/assets/images/profile-image.png')); ?>" width="130" height="130" alt="<?php echo e($post->capa ?? null); ?>" style="border-radius:100%;" />
                        <?php endif; ?>
                    </div>
                    <div class="blog-post__description">
                        <div class="blog-post__date"><span><?php echo e(date('d/m/Y', strtotime($post->created_at)) ?? null); ?></span></div>
                        <a href="#" class="blog-post__category"><?php echo e($post->categoria->descricao ?? null); ?></a>

                        <h2 class="blog-post__title"><?php echo e(mb_strimwidth($post->titulo, 0, 38, "...")); ?></h2>
                        <p class="blog-post__excerpt">
                            <?php echo e(mb_strimwidth(strip_tags(trim($post->conteudo)), 0, 200, "...")); ?>

                        </p>

                        <a href="<?php echo e(route('site.blog.show', $post->slug)); ?>" class="blog-post__read-more">Leia Mais...</a>
                    </div>
                </section>
                <footer class="blog-post__tags">
                    
                </footer>
            </article>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\jobs\portalpcd\resources\views/site/home/index.blade.php ENDPATH**/ ?>