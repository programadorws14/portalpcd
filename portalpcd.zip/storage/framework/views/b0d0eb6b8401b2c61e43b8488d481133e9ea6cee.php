<div class="row">
    <?php echo csrf_field(); ?>

    <?php if(!empty($admin)): ?>
        <input type="hidden" class="form-control" value="<?php echo e($admin->id ?? null); ?>" name="id" required>
    <?php endif; ?>

    <div class="col-md-4">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Nome</div>
            </div>
        <input type="text" class="form-control" value="<?php echo e($admin->nome ?? old('nome')); ?>" name="nome" required>
        </div>
    </div>
    <div class="col-md-4">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">E-mail</div>
            </div>
            <input type="email" id="emailPerfil" class="form-control" value="<?php echo e($admin->email ?? old('email')); ?>" name="email" required>
            <small style="font-size:13px; color:red;  width:100%;" id="msgErroMail"></small>
        </div>
    </div>
    <div class="col-md-4">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Senha</div>
            </div>
            <input type="password" class="form-control" value="" name="password">
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views/admin/gerenciar_admin/_form.blade.php ENDPATH**/ ?>