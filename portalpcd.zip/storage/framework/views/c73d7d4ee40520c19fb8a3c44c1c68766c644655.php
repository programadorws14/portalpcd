<?php $__env->startSection('content'); ?>

<section class="login">
    <div class="login-container">
        <header class="section-heading  pcd-container">
            <h1><strong>Login Administrador</strong></h1>
            <hr />
        </header>
        <div class="forms-area">
            <form action="<?php echo e(route('login')); ?>" style="margin:0 auto !important;" class="default-form" id="candidato" method="POST">
                <?php echo csrf_field(); ?>
                <h2 class="form-title">Sou Administrador - Quero me logar</h2>

                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                <input type="email" placeholder="Digite seu e-mail" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                   
                <input type="password" placeholder="Digite sua senha" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password"  required autocomplete="current-password">
                 
                    <input style="display:none;" class="form-check-input" type="checkbox" name="remember" id="remember" checked>
                <input type="submit" value="Entrar">
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views/auth/login.blade.php ENDPATH**/ ?>