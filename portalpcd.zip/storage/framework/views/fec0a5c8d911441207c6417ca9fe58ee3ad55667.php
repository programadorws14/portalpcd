<div class="table-responsive">
    <table class="tabelaDinamica table  table-bordered table-hover table-sm">
        <thead class="thead-light">
            <tr>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Nome</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">E-mail</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Ação</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php if(count($newsletters) > 0): ?>
                <?php $__currentLoopData = $newsletters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newletter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle p-2"><?php echo e($newletter->nome ?? 'N/I'); ?></td>
                        <td class="align-middle p-2"><?php echo e($newletter->email ?? 'N/I'); ?></td>
                        <td class="align-middle p-2">
                            <a href="<?php echo e(route('admin.newsletter.deletar', $newletter->id)); ?>" onClick="return confirm('Deseja mesmo deletar ?')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
</div><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views/admin/gerenciar_newsletter/_list.blade.php ENDPATH**/ ?>