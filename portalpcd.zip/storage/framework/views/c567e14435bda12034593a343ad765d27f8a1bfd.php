<?php $__env->startSection('content'); ?>

<header class="section-heading pcd-container">
    <h1>Home / Vaga <strong><?php echo e(' / '. $vaga->titulo ?? null); ?></strong></h1>
    <hr />
</header>

<div class="wrapper container-fluid">
    <div class="row">
        <div class="col-xs-12 col-md-3 profile__info">
            <img src="<?php echo e(asset('site/assets/images/profile-image.png')); ?>" alt="" />
            <h2 class="profile__title"><?php echo e($vaga->empresa->nome ?? null); ?></h2>
            <p class="profile__username"><?php echo e('/'. $vaga->empresa->nome_url ?? null); ?></p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3 col-xs-12">
            <section class="profile">
                <div class="profile__card">
                    <section class="profile__section">
                        <h2>
                            Detalhes do trabalho <i class="fas fa-chevron-down"></i>
                        </h2>
                        <ul>
                            <li>Vagas disponíveis: <?php echo e($vaga->numero_vaga ?? null); ?></li>
                            <li>Data de publicação: <?php echo e(date('d/m/Y H:i:s', strtotime($vaga->created_at)) ?? null); ?></li>
                            <li>Local: <?php echo e($vaga->cidade. ' | '. $vaga->estado ?? null); ?></li>
                            <li>Tipo de emprego: <?php echo e($vaga->tipo_emprego ?? null); ?></li>
                            <li>Salário: <?php echo e(( $vaga->salario_de ? number_format($vaga->salario_de,2,",",".") : 'A Combinar' )); ?>  <?php echo e(( $vaga->salario_ate ? ' - '.number_format($vaga->salario_ate,2,",",".") : 'A Combinar' )); ?> </li>
                        </ul>
                    </section>
                </div>
            </section>
        </div>
        <div class="col-md-8 col-md-offset-1 col-xs-12">
            <section class="descricao-vaga negative">
                <div class="header-descicao-vaga">
                    <h2 class="title">Descição da vaga</h2>
                </div>
                <div class="content-descricao-vaga">
                    <div class="content">
                        <p><?php echo e($vaga->descricao_vaga ?? 'Descrição não informada pela empresa.'); ?></p>
                    </div>
                    <?php if(Session('success')): ?>
                    <div class="alert alert-success" style="margin:20px 0; color:green;">
                        <b><i class="fas fa-check"></i> <?php echo e(Session('success')); ?></b>
                    </div>
                    <?php elseif(Session('error')): ?>
                    <div class="alert alert-danger" style="margin:20px 0; color:red;">
                        <b><i class="fas fa-times-circle"></i> <?php echo e(Session('error')); ?></b>
                    </div>
                    <?php endif; ?>

                    <?php if(!Auth::guard('usuario')->user()): ?>
                        <div class="col-md-12" style="margin:40px 0;">
                            <a class="botao-link" style="background:#00b7dd !important; text-decoration:none; color:#FFF; font-size:16px !important; padding:10px;" href="<?php echo e(route('site.login.candidato')); ?>">Logar para Candidatar-se</a>
                        </div>
                    <?php else: ?>
                        <?php if(count($vaga->candidatos) >= 1): ?>
                            <?php $__currentLoopData = $vaga->candidatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($candidato->id == Auth::guard('usuario')->user()->id): ?>
                                <br/>
                                    <span style="background:#0086a5; margin-top:15px; color:#FFF; padding:5px; border-radius:10px;"><b><?php echo e(Auth::guard('usuario')->user()->nome); ?></b>, você já está cadastrado nessa vaga!</span>
                                    <span style="display:block; margin-top:15px; "><b>Cadastro efetuado em:</b> <?php echo e(date('d/m/Y', strtotime($candidato->created_at)) ?? null); ?> </span>
                                <?php else: ?>
                                    <div class="col-md-12" style="margin:40px 0;">
                                        <a class="botao-link" style="text-decoration:none; color:#FFF; font-size:16px !important; padding:10px;" href="<?php echo e(route('usuario.candidatar.vaga', $vaga->id)); ?>">Candidatar-se</a>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    </div>
</div>

<header class="section-heading  pcd-container">
    <h1>Confira <strong>MAIS VAGAS</strong></h1>
    <hr />
    <a href="#">Confira todas as Vagas</a>
</header>

<section class="jobs-card__container  pcd-container">
    <div class="row search-form__row">
        
        <?php $__currentLoopData = $vagas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($v->id != $vaga->id): ?>
            <div class="col-xs-12 col-md-4" style="margin-top:25px;">
                <article class="jobs-card">
                    <section class="jobs-card__header">
                        <div class="jobs-card__image">
        
                            <?php if(!empty($v->empresa->logo_empresa)): ?>
                            <img src="<?php echo e(asset($v->empresa->logo_empresa)); ?>" width="90" height="90" alt="<?php echo e($v->empresa->nome ?? null); ?>" />
                            <?php else: ?>
                            <img src="<?php echo e(asset('img/img-empresa.png')); ?>" width="90" height="90" alt="<?php echo e($v->empresa->nome ?? null); ?>" />
                            <?php endif; ?>
        
                        </div>
                        <div class="jobs-card__description">
                            <h2 class="jobs-card__title"><a href="<?php echo e(route('site.vagas.show', $v->id)); ?>"><?php echo e(substr($v->titulo, 0, 20) ?? null); ?></a></h2>
                            <h4 class="jobs-card__subtitle"><?php echo e(substr($v->descricao_vaga, 0, 65) ?? null); ?></h4>
                        </div>
                    </section>
                    <footer class="jobs-card__footer">
                        <p class="jobs-card__location">
                            <i class="fas fa-location-arrow"></i>&nbsp; <?php echo e($v->cidade ?? null); ?> - <?php echo e($v->estado ?? null); ?>

                        </p>
                        <p class="jobs-card__date">
                            <i class="fas fa-calendar"></i>&nbsp; Publicado em: <?php echo e(date('d/m/Y', strtotime($v->created_at)) ?? null); ?>

                        </p>
                    </footer>
                </article>
            </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views\site\vaga\vaga_single.blade.php ENDPATH**/ ?>