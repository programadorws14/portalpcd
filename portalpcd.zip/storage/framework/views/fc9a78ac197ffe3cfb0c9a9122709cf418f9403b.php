<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    <!--Icones--->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>

<body>
    <div id="app">
        <?php if(!empty(Auth::guard('admin')->user())): ?>
        <nav class="navbar navbar-expand-md  bg-primary menu">
            <div class="container-fluid">
                <a class="navbar-brand" href="">
                    <img src="<?php echo e(asset('img/logo.jpg')); ?>" class="rounded-circle img-fluid" width="50" title="<?php echo e(config('app.name', 'Laravel')); ?>">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                        <li class="nav-item ">
                            <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link"><i class="fas fa-home"></i></a>
                        </li>


                        <!---- Variavel data['vagasPendentes'] está vindo do appServive boot--->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-truck-loading"></i> Empresas <?php if(count($data['empresasPendentes']) > 0): ?><span class="badge badge-danger"><?php echo e(count($data['empresasPendentes'])); ?></span><?php endif; ?>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('admin.empresa.create')); ?>"> <i class="fas fa-plus"></i> Nova </a>
                                <a class="dropdown-item" href="<?php echo e(route('admin.empresa.listar')); ?>""> <i class=" fas fa-building"></i> Lista </a>
                                <a class="dropdown-item" href="<?php echo e(route('admin.empresa.pendente')); ?>"> <i class="fas fa-hourglass-end"></i> Pendentes <?php if(count($data['empresasPendentes']) > 0): ?><span class="badge badge-warning"><?php echo e(count($data['empresasPendentes'])); ?></span><?php endif; ?> </a>
                                <a class="dropdown-item" href="<?php echo e(route('admin.empresa.recusadas')); ?>"> <i class="fas fa-times-circle"></i> Recusadas </a>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-address-book"></i> Vagas <?php if(count($data['vagasPendentes']) > 0): ?><span class="badge badge-danger"><?php echo e(count($data['vagasPendentes'])); ?></span><?php endif; ?>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('admin.vaga.listar')); ?>""> <i class=" fas fa-building"></i> Lista </a>
                                <a class="dropdown-item" href="<?php echo e(route('admin.vaga.pendente')); ?>"> <i class="fas fa-hourglass-end"></i> Pendentes <?php if(count($data['vagasPendentes']) > 0): ?><span class="badge badge-warning"><?php echo e(count($data['vagasPendentes'])); ?></span><?php endif; ?> </a>
                                <a class="dropdown-item" href="<?php echo e(route('admin.vaga.recusadas')); ?>"> <i class="fas fa-times-circle"></i> Recusadas </a>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-blog"></i> Blog
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('admin.blog.index')); ?>"> <i class="fas fa-file"></i> Posts</a>
                                <a class="dropdown-item" href="<?php echo e(route('admin.blog.categoria.index')); ?>"> <i class="fas fa-tag"></i> Categorias</a>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-cogs"></i> Config
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('admin.config.profissao.index')); ?>"> <i class="fas fa-id-badge"></i> Profissão</a>
                                <a class="dropdown-item" href=""> <i class="fas fa-users"></i> Usuários</a>
                            </div>
                        </li>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item ">
                            <a href="<?php echo e(url('/')); ?>" target="_blank" class="btn btn-secondary "><i class="fas fa-satellite"></i></a>
                        </li>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link Fdropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <b><i class="fas fa-user"></i> <?php echo e(Auth::guard('admin')->user()->nome); ?> <span class="caret"></span></b>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#"> <i class="fas fa-lock"></i> Alterar Senha</a>
                                <a class="dropdown-item" href="<?php echo e(route('admin.sair')); ?>" onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                    <i class="fas fa-sign-out-alt"></i> Sair
                                </a>
                                <form id="logout-form" action="<?php echo e(route('admin.sair')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <?php endif; ?>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="//cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
    <script>
        $(function() {

        })
        $('.tabelaDinamica').dataTable({
            language: {
                sEmptyTable: 'Nenhum registro encontrado',
                sInfo: 'Mostrando de _START_ até _END_ de _TOTAL_ registros',
                sInfoEmpty: 'Mostrando 0 até 0 de 0 registros',
                sInfoFiltered: '(Filtrados de _MAX_ registros)',
                sInfoPostFix: '',
                sInfoThousands: '.',
                sLengthMenu: '_MENU_ Registros por página',
                sLoadingRecords: 'Carregando...',
                sProcessing: 'Processando...',
                sZeroRecords: 'Nenhum registro encontrado',
                sSearch: 'Pesquisar',
                oPaginate: {
                    sNext: 'Próximo',
                    sPrevious: 'Anterior',
                    sFirst: 'Primeiro',
                    sLast: 'Último'
                },
                order: []
            }
        });
    </script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views\admin\layouts\app.blade.php ENDPATH**/ ?>