<?php $__env->startSection('content'); ?>

<header class="section-heading pcd-container">
    <h1>PCD / <strong>BLOG</strong></h1>
    <hr />
</header>

<div class="wrapper container-fluid">
    <div class="row">

        <div class="col-xs-12 col-md-5" style=" margin:0 auto; height:240px; background:url(<?php echo e(( $post->capa ? asset($post->capa) : asset('site/assets/images/profile-image.png') )); ?>) center; background-size:100%; z-index:9999;">

        </div>

        <div class="col-md-8 col-xs-5" style="margin: -70px auto 0;">
            <section class="descricao-vaga negative page">
                <div class="content-descricao-vaga">
                    <div class="content" style="padding-top:70px;">

                        <small style="margin-bottom:20px; float:left; width:100%;    color:#CCC;">Data: <?php echo e(date('d/m/Y', strtotime($post->created_at))); ?> | Categoria: <?php echo e($post->categoria->descricao ?? 'Sem Categoria'); ?></small>
                        <p><?php echo $post->conteudo; ?></p>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\jobs\portalpcd\resources\views/site/blog/blog_single.blade.php ENDPATH**/ ?>