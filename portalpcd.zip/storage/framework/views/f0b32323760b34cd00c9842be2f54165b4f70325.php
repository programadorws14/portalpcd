<div class="container-fluid mt-3">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Listar Profissões</div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="tabelaDinamica table table-striped table-bordered table-hover table-sm">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2">Descrição</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="10%">Status</th>
                                    <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="10%">Ação</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php $__currentLoopData = $profissoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profissao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-middle"><?php echo e($profissao->descricao ?? null); ?></td>
                                    <td class="align-middle">
                                        <?php if($profissao->status == 1): ?>
                                        <span class="badge badge-success">ATIVO</span>
                                        <?php elseif($profissao->status == 2): ?>
                                        <span class="badge badge-danger">INATIVO</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="align-middle">
                                        <a href="<?php echo e(route('admin.config.profissao.edit',$profissao->id )); ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a>
                                        <a href="<?php echo e(route('admin.config.profissao.delete',$profissao->id )); ?>" onClick="return confirm('Deseja mesmo deletar ?')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views\admin\config\profissao\list.blade.php ENDPATH**/ ?>