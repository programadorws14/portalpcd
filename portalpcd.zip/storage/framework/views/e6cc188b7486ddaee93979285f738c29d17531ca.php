<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <form>
                <div class="card">
                    <div class="card-header">Detalhes: <b><?php echo e($edit->nome ?? null); ?></b> </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <?php if(!empty($edit->logo)): ?>
                                <img style="border:1px solid #ccc;" src="<?php echo e(asset($edit->logo)); ?>" width="120" height="120 " class="img-fluid" alt="<?php echo e($edit->nome); ?>" title="<?php echo e($edit->nome); ?>">
                                <?php else: ?>
                                <img style="border:1px solid #ccc;" src="<?php echo e(asset('img/img-empresa.png')); ?>" width="120" height="120" class="img-fluid" alt="<?php echo e($edit->nome); ?>" title="<?php echo e($edit->nome); ?>">
                                <?php endif; ?>
                            </div>

                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">E-mail</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->nome ?? null); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Descrição</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->descricao ?? null); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Ramo</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->ramo ?? null); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Qtd Funcionários</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->qtd_funcionarios ?? null); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Data Fundação</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e(date('d/m/Y', strtotime($edit->data_fundacao)) ?? null); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Especialidades</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->especialidades ?? null); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Organização</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->organizacao ?? null); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Links</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->links ?? null); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Telefone</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->telefone ?? null); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Especialidades</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->especialidades ?? null); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Endereço</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->endereco ?? null); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Estado</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->estado[0]->nome ?? null); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Municipio</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($municipio->nome ?? null); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Site</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->site ?? null); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group input-group-sm mb-4">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Especialidades</div>
                                    </div>
                                    <input type="text" class="form-control" value="<?php echo e($edit->especialidades ?? null); ?>" disabled>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('admin.empresa.aprovar', $edit->id)); ?>" class="btn btn-success btn-sm"><i class="fas fa-check"></i> Aprovar</a>
                        <a href="<?php echo e(route('admin.empresa.recusar', $edit->id)); ?>" onClick="return confirm('Deseja mesmo Recusar ?')" class="btn btn-danger btn-sm"><i class="fas fa-minus"></i> Recusar</a>
                        <a href="<?php echo e(route('admin.empresa.pendente')); ?>" class="btn btn-primary btn-sm"><i class="fas fa-arrow-left"></i> Cancelar</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views\admin\gerenciar_empresa\detalhes.blade.php ENDPATH**/ ?>