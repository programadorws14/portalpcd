<div class="row">
    <?php echo csrf_field(); ?>

    <?php if(!empty($vaga)): ?>
    <input type="hidden" class="form-control" value="<?php echo e($vaga->id ?? null); ?>" name="id" required>
    <?php endif; ?>

    <div class="col-md-4">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Empresa</div>
            </div>
            <select name="empresa_id" class="form-control">
                <option value="">Selecione</option>
                <?php if(count($empresas) > 0): ?>
                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php if(!empty($vaga->empresa_id) && $vaga->empresa_id == $empresa->id): ?> selected <?php endif; ?> value="<?php echo e($empresa->id ?? null); ?>"><?php echo e($empresa->nome ?? null); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </div>
    </div>
    <div class="col-md-4">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Titulo</div>
            </div>
            <input type="text" class="form-control" value="<?php echo e($vaga->titulo ?? old('titulo')); ?>" name="titulo">
        </div>
    </div>
    <div class="col-md-4">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Salário Acombinar </div>
            </div>
            <select name="salario_acombinar" id="salario_acombinar" class="form-control">
                <option <?php if(!empty($vaga) && $vaga->salario_acombinar != ''): ?> selected <?php endif; ?> value="Sim">Sim</option>
                <option <?php if(!empty($vaga) && $vaga->salario_acombinar == ''): ?> selected <?php endif; ?> value="Não">Não</option>
            </select>
        </div>
    </div>
    <div class="col-md-2">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Salário de:</div>
            </div>
            <input type="text" id="salario_de" class="form-control" value="<?php echo e($vaga->salario_de ?? old('salario_de')); ?>" name="salario_de" disabled>
        </div>
    </div>
    <div class="col-md-2">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Salário ate:</div>
            </div>
            <input type="text" id="salario_ate" class="form-control" value="<?php echo e($vaga->salario_ate ?? old('salario_ate')); ?>" name="salario_ate" disabled>
        </div>
    </div>
    <div class="col-md-4">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Pausar Vaga</div>
            </div>
            <select name="pausar_vaga" class="form-control">
                <option value="">Selecione</option>
                <option <?php if(!empty($vaga) && $vaga->pausar_vaga != ''): ?> selected <?php endif; ?> value="Sim">Sim</option>
                <option <?php if(!empty($vaga) && $vaga->pausar_vaga == ''): ?> selected <?php endif; ?> value="Não">Não</option>
            </select>
        </div>
    </div>
    <div class="col-md-2">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Tipo Emprego</div>
            </div>
            <select name="tipo_emprego" class="form-control">
                <option value="">Selecione</option>
                <option <?php if(!empty($vaga) && $vaga->tipo_emprego == 'CLT'): ?> selected <?php endif; ?> value="CLT">CLT</option>
                <option <?php if(!empty($vaga) && $vaga->tipo_emprego == 'PJ'): ?> selected <?php endif; ?> value="PJ">PJ</option>
            </select>
        </div>
    </div>
    <div class="col-md-2">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Número Vaga(s)</div>
            </div>
            <input type="text" class="form-control" value="<?php echo e($vaga->numero_vagas ?? old('numero_vagas')); ?>" name="numero_vagas">
        </div>
    </div>
    <div class="col-md-12">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Descrição</div>
            </div>
            <textarea class="form-control" name="descricao_vaga" rows="3"><?php echo e($vaga->descricao_vaga ?? old('descricao_vaga')); ?></textarea>
        </div>
    </div>
    <div class="col-md-4">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">CEP</div>
            </div>
            <input type="text" class="form-control" value="<?php echo e($vaga->cep ?? old('cep')); ?>" id="cep" name="cep">
        </div>
    </div>
    <div class="col-md-4">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Rua</div>
            </div>
            <input type="text" class="form-control" value="<?php echo e($vaga->rua ?? old('rua')); ?>" id="rua" name="rua" <?php if(empty($vaga->rua)): ?> disabled <?php endif; ?>>
        </div>
    </div>
    <div class="col-md-4">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Número</div>
            </div>
            <input type="text" class="form-control" value="<?php echo e($vaga->numero ?? old('numero')); ?>" id="numero" name="numero" <?php if(empty($vaga->numero)): ?> disabled <?php endif; ?>>
        </div>
    </div>
    <div class="col-md-4">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Complemento</div>
            </div>
            <input type="text" class="form-control" value="<?php echo e($vaga->complemento ?? old('complemento')); ?>" id="complemento" name="complemento" <?php if(empty($vaga)): ?> disabled <?php endif; ?>>
        </div>
    </div>
    <div class="col-md-4">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Bairro</div>
            </div>
            <input type="text" class="form-control" id="bairro" value="<?php echo e($vaga->bairro ?? old('bairro')); ?>" name="bairro" <?php if(empty($vaga->bairro)): ?> disabled <?php endif; ?>>
        </div>
    </div>
    <div class="col-md-2">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Cidade</div>
            </div>
            <input type="text" class="form-control" id="cidade" value="<?php echo e($vaga->cidade ?? old('cidade')); ?>" name="cidade" <?php if(empty($vaga->cidade)): ?> disabled <?php endif; ?>>
        </div>
    </div>
    <div class="col-md-2">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <div class="input-group-text">Estado</div>
            </div>
            <input type="text" class="form-control" id="estado" value="<?php echo e($vaga->estado ?? old('estado')); ?>" name="estado" <?php if(empty($vaga->estado)): ?> disabled <?php endif; ?>>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views/admin/gerenciar_vaga/_form.blade.php ENDPATH**/ ?>