<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Usuários</div>
                <div class="card-body">
                    <a href="<?php echo e(route('admin.gerenciar.create')); ?>" class="btn btn-success mb-3"><i class="fas fa-plus"></i> Novo</a>
                    <?php if(Session('success')): ?>
                    <div class="alert alert-success">
                        <b><i class="fas fa-check"></i> <?php echo e(Session('success')); ?></b>
                    </div>
                    <?php elseif(Session('error')): ?>
                    <div class="alert alert-danger">
                        <b><i class="fas fa-minus"></i> <?php echo e(Session('error')); ?></b>
                    </div>
                    <?php endif; ?>

                    <?php echo $__env->make('admin.gerenciar_usuario._list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\jobs\portalpcd\resources\views/admin/gerenciar_usuario/index.blade.php ENDPATH**/ ?>