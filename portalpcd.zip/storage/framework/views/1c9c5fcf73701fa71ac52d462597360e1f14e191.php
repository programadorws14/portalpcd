<?php echo csrf_field(); ?>

<?php if(!empty($edit)): ?>
<input type="hidden" name="id" value="<?php echo e($edit->id); ?>" />
<?php endif; ?>

<div class="col-md-12">
    <div class="input-group input-group-sm mb-4">
        <div class="input-group-prepend">
            <div class="input-group-text">Descrição</div>
        </div>
        <input type="text" class="form-control" value="<?php if(!empty($edit)): ?> <?php echo e($edit->descricao); ?> <?php else: ?> <?php echo e(old('descricao')); ?> <?php endif; ?>" name="descricao">
    </div>
</div><?php /**PATH C:\wamp64\www\wallace\portalpcd\resources\views/admin/gerenciar_blog/categoria/_form.blade.php ENDPATH**/ ?>