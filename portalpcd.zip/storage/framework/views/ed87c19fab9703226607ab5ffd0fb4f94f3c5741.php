<div class="table-responsive">
    <table class="tabelaDinamica table table-bordered table-sm">
        <thead class="thead-light">
            <tr>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="5%">Capa</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="40%">Titulo</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="10%">Categoria</th>
                <th scope="col" style="font-size: 1em;" class="align-middle pl-2" width="5%">Ação</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="align-middle">
                    <?php if(!empty($post->capa)): ?>
                    <img style="border:1px solid #ccc;" src="<?php echo e(asset($post->capa)); ?>" width="120" height="120" class="img-fluid" alt="<?php echo e($post->titulo); ?>" title="<?php echo e($post->titulo); ?>">
                    <?php else: ?>
                    <img style="border:1px solid #ccc;" src="<?php echo e(asset('img/img-empresa.png')); ?>" width="120" height="120" class="img-fluid" alt="<?php echo e($post->titulo); ?>" title="<?php echo e($post->titulo); ?>">
                    <?php endif; ?>
                </td>
                <td class="align-middle"><?php echo e($post->titulo ?? null); ?></td>
                <td class="align-middle"><?php echo e($post->categoria->descricao ?? null); ?></td>
                <td class="align-middle">
                    <a href="#" class="btn btn-warning btn-sm"><i class="fas fa-eye"></i></a>
                    <a href="<?php echo e(route('admin.blog.edit', $post->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a>
                    <a href="<?php echo e(route('admin.blog.delete', $post->id)); ?>" onClick="return confirm('Deseja mesmo deletar ?')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\wamp64\www\jobs\portalpcd\resources\views/admin/gerenciar_blog/_list.blade.php ENDPATH**/ ?>